import { CONFIG } from 'src/config-global';

import { PostListHomePageView } from 'src/sections/blog/view';

// ----------------------------------------------------------------------

export const metadata = { title: `Post list - ${CONFIG.site.name}` };

export default function Page() {
  return <PostListHomePageView />;
}
