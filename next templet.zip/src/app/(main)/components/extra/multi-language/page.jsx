import { CONFIG } from 'src/config-global';

import { MultiLanguageView } from 'src/sections/_examples/extra/multi-language-view';

// ----------------------------------------------------------------------

export const metadata = { title: `Multi language | Components - ${CONFIG.site.name}` };

export default function Page() {
  return <MultiLanguageView />;
}
