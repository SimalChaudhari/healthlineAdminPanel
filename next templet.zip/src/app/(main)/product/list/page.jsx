import { CONFIG } from 'src/config-global';

import { ProductShopPageView } from 'src/sections/product/view';

// ----------------------------------------------------------------------

export const metadata = { title: `Product shop - ${CONFIG.site.name}` };

export default function Page() {
  return <ProductShopPageView />;
}
