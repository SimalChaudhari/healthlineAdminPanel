'use client';

import { Suspense } from 'react';

import { SplashScreen } from 'src/components/loading-screen';

import { GuestGuard } from 'src/auth/guard';

export default function Layout({ children }) {
  return (
    <Suspense fallback={<SplashScreen />}>
      <GuestGuard>{children}</GuestGuard>
    </Suspense>
  );
}
