'use client';

import { Suspense } from 'react';

import { AuthSplitLayout } from 'src/layouts/auth-split';

import { SplashScreen } from 'src/components/loading-screen';

import { GuestGuard } from 'src/auth/guard';

export default function Layout({ children }) {
  return (
    <Suspense fallback={<SplashScreen />}>
      <GuestGuard>
        <AuthSplitLayout>{children}</AuthSplitLayout>
      </GuestGuard>
    </Suspense>
  );
}
